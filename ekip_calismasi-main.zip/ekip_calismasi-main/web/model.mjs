export const games=[['King','♛'],['Okey','▦'],['101','₁₀₁'],['Küt','♦'],['Batak','♠'],['Pişti','♣']];
export const variants={'İhaleli':4,'İhalesiz':4,'Eşli':2,'Gömmeli (3 kişi)':3,'3-5-8':3};
export function totals(m){return m.players.map((_,i)=>m.rounds.reduce((sum,r)=>sum+r.scores[i],0));}
export function leaders(m){if(!m.rounds.length)return [];const t=totals(m),best=m.low?Math.min(...t):Math.max(...t);return m.players.filter((_,i)=>t[i]===best);}
export function resultSummary(m){
  const winners=leaders(m);
  if(!winners.length)return 'İlk el sizden.';
  if(winners.length>1)return `${m.finished?'Beraberlik':'Eşit puan'} · ${winners.join(' & ')}`;
  return `${winners[0]} ${m.finished?'kazandı':'önde'}`;
}
export function validScores(scores,count){return Array.isArray(scores)&&Number.isInteger(count)&&count>0&&scores.length===count&&scores.every(n=>Number.isInteger(n)&&Math.abs(n)<=100000);}
export function roll(count){return Array.from({length:count},()=>secureInt(6)+1);}
export function secureInt(max){const a=new Uint32Array(1),limit=Math.floor(4294967296/max)*max;do{crypto.getRandomValues(a);}while(a[0]>=limit);return a[0]%max;}

export const storageKey='masa-preview-v1';
const record=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
export function validMatch(m){
  if(!record(m)||typeof m.id!=='string'||!m.id.trim()||!games.some(([name])=>name===m.game))return false;
  if(m.variant!==null&&(typeof m.variant!=='string'||!Object.hasOwn(variants,m.variant)))return false;
  if(m.game==='Batak'?!Object.hasOwn(variants,m.variant):m.variant!==null)return false;
  if(!Array.isArray(m.players)||m.players.length<2||m.players.length>6||!m.players.every(p=>typeof p==='string'&&p.trim().length>0&&p.length<=40))return false;
  if(m.game==='Batak'&&m.players.length!==variants[m.variant])return false;
  if(typeof m.low!=='boolean'||typeof m.finished!=='boolean'||!Number.isSafeInteger(m.created)||m.created<0||m.created>8640000000000000)return false;
  return Array.isArray(m.rounds)&&(!m.finished||m.rounds.length>0)&&m.rounds.every(r=>record(r)&&validScores(r.scores,m.players.length)&&typeof r.note==='string'&&r.note.length<=200);
}
export function validMatches(value){
  return Array.isArray(value)&&value.every(validMatch)&&new Set(value.map(m=>m.id)).size===value.length;
}
// A whole-store lock preserves every original byte when any record is incompatible.
export function readMatches(storage){
  let raw=null;
  try{
    raw=storage.getItem(storageKey);
    const matches=raw===null?[]:JSON.parse(raw);
    if(!validMatches(matches))return {matches:[],locked:true,raw,reason:'format'};
    return {matches,locked:false,raw};
  }catch{return {matches:[],locked:true,raw,reason:raw===null?'access':'format'};}
}
export function writeMatches(storage,next,state){
  if(state.locked)return {ok:false,reason:'locked'};
  if(!validMatches(next))return {ok:false,reason:'format'};
  // Another tab can change the same store: refuse to overwrite unseen changes.
  try{
    if(storage.getItem(storageKey)!==state.raw)return {ok:false,reason:'conflict'};
    const raw=JSON.stringify(next);
    storage.setItem(storageKey,raw);
    return {ok:true,raw};
  }catch{return {ok:false,reason:'access'};}
}

# Katkıda bulunma

Önce [ekip rehberini](docs/EKIP_REHBERI.md) oku. Her iş için görev ve ayrı dal kullan. Pull request açıklamasına sorunu, değişikliği ve yapılan testi yaz; ana sürüme almadan önce başka bir ekip üyesinden inceleme iste.

- Web kontrolü: `node --check web/app.mjs` ve `node --test web/model.test.mjs`.
- iOS mantık kontrolü (Mac): `swiftc ios/Masa/Game.swift ios/Tests/main.swift -o /tmp/masa-tests` ve `/tmp/masa-tests`.
- iOS ekran/derleme kontrolü: `ios/Masa.xcodeproj` dosyasını Xcode ile aç.

GitHub Actions her gönderimde web testlerini ve Mac üzerinde iOS mantık testleri ile imzasız simülatör derlemesini çalıştırır. Hangi kontrollerin geçtiğini pull request üzerinde gör. Fiziksel iPhone deneyimi ayrıca kontrol edilmelidir.

Oyun kurallarını varsayma; önce [kural kararlarına](docs/OYUN_KURALLARI.md) örnek ekle. Kullanıcı maçlarını, kişisel dosyaları, şifreleri, sertifikaları veya erişim anahtarlarını repoya koyma.

import SwiftUI

@main
struct MasaApp: App {
    @StateObject private var store = MatchStore()
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).tint(.mint).preferredColorScheme(.dark)
                .alert("Kayıt sorunu", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
                    Button("Tamam") { store.error = nil }
                } message: { Text(store.error ?? "") }
        }
    }
}

@MainActor final class MatchStore: ObservableObject {
    @Published var matches: [Match] = []
    @Published var error: String?
    private let archive: MatchArchive
    private var canSave = true
    init() {
        archive = MatchArchive(url: URL.applicationSupportDirectory.appending(path: "Masa/matches.json"))
        do { matches = try archive.load() }
        catch { self.error = "Kayıtlar okunamadı. Mevcut dosyayı korumak için yeni kayıt kapatıldı."; canSave = false }
    }
    @discardableResult func put(_ match: Match) -> Bool {
        guard canSave else { error = "Kayıt dosyası okunamıyor. Mevcut veriler korunuyor."; return false }
        var next = matches
        if let index = next.firstIndex(where: { $0.id == match.id }) { next[index] = match }
        else { next.insert(match, at: 0) }
        do { try archive.save(next); matches = next; error = nil; return true }
        catch { self.error = "Değişiklik kaydedilemedi. Lütfen tekrar dene."; return false }
    }
    func remove(_ id: UUID) {
        guard canSave else { return }
        let next = matches.filter { $0.id != id }
        do { try archive.save(next); matches = next }
        catch { self.error = "Maç silinemedi. Lütfen tekrar dene." }
    }
}

private let canvas = Color(red: 0.035, green: 0.075, blue: 0.065)
private let panel = Color(red: 0.075, green: 0.135, blue: 0.115)

struct RootView: View {
    var body: some View {
        TabView {
            HomeView().tabItem { Label("Masa", systemImage: "square.grid.2x2") }
            HistoryView().tabItem { Label("Geçmiş", systemImage: "clock") }
            ToolsView().tabItem { Label("Araçlar", systemImage: "dice") }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject var store: MatchStore
    @State private var selection: GameKind?
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 25) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("BİR MASA, BİR SÜRÜ HİKÂYE").font(.caption.weight(.bold)).tracking(2).foregroundStyle(.mint)
                        Text("Oyun sizden.\nHesap bizden.").font(.system(size: 38, weight: .bold, design: .rounded))
                        Text("Arkadaşlarını topla, oyunu seç, masaya otur.").foregroundStyle(.secondary)
                    }.padding(.vertical, 16)
                    if let match = store.matches.first(where: { !$0.finished }) {
                        NavigationLink { MatchView(id: match.id) } label: {
                            HStack {
                                Image(systemName: "play.circle.fill").font(.largeTitle)
                                VStack(alignment: .leading) {
                                    Text("Masaya dön").font(.headline)
                                    Text("\(match.title) · \(match.rounds.count) el oynandı").font(.caption)
                                }
                                Spacer(); Image(systemName: "arrow.right")
                            }.padding(20).background(.mint.opacity(0.15), in: RoundedRectangle(cornerRadius: 22))
                        }.buttonStyle(.plain)
                    }
                    Text("Bu akşam ne oynuyoruz?").font(.title3.bold())
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                        ForEach(GameKind.allCases) { kind in
                            Button { selection = kind } label: {
                                VStack(alignment: .leading, spacing: 22) {
                                    Image(systemName: kind.symbol).font(.system(size: 29)).foregroundStyle(.mint)
                                    HStack { Text(kind.rawValue).font(.title3.bold()); Spacer(); Image(systemName: "arrow.up.right").font(.caption) }
                                }.padding(22).frame(maxWidth: .infinity, alignment: .leading).background(panel, in: RoundedRectangle(cornerRadius: 24))
                            }.buttonStyle(.plain)
                        }
                    }
                    Label("Hesap açmadan, internet gerektirmeden.", systemImage: "checkmark.shield").font(.caption).foregroundStyle(.secondary)
                }.padding(22)
            }.background(canvas).navigationTitle("masa").navigationBarTitleDisplayMode(.inline)
                .sheet(item: $selection) { NewMatchView(kind: $0) }
        }
    }
}

struct NewMatchView: View {
    let kind: GameKind
    @EnvironmentObject var store: MatchStore
    @Environment(\.dismiss) private var dismiss
    @State private var count = 4
    @State private var names = Array(repeating: "", count: 6)
    @State private var lowWins = false
    @State private var teams = false
    @State private var batakVariant: BatakVariant = .ihaleli
    private var usesTeams: Bool { kind == .batak ? batakVariant.isTeam : teams }
    private var scoreCount: Int { kind == .batak ? batakVariant.scoreCount : (teams ? 2 : count) }
    var body: some View {
        NavigationStack {
            Form {
                if kind == .batak {
                    Section("Batak türü") {
                        Picker("Oyun türü", selection: $batakVariant) {
                            ForEach(BatakVariant.allCases) { variant in Text(variant.rawValue).tag(variant) }
                        }
                        LabeledContent("Masa", value: batakVariant.arrangement)
                    }
                }
                Section("Masa düzeni") {
                    if kind != .batak {
                        Toggle("Takım olarak puan tut", isOn: $teams)
                        if !teams { Stepper("\(count) oyuncu", value: $count, in: 2...6) }
                    }
                    ForEach(0..<scoreCount, id: \.self) { index in
                        TextField("\(usesTeams ? "Takım" : "Oyuncu") \(index + 1)", text: $names[index]).textInputAutocapitalization(.words)
                    }
                }
                Section {
                    Toggle("Düşük toplam puan kazansın", isOn: $lowWins)
                } header: { Text("Puanlama") } footer: {
                    Text("Bu prototipte her elin sonuç puanını girersin. Özel cezaları puana dahil edebilirsin. Batak türüne göre masa düzeni hazır gelir. Kazanma yönünü masanın kurallarına göre seç.")
                }
                Section {
                    Button("Masayı kur") {
                        let players = (0..<scoreCount).map { index in
                            let name = names[index].trimmingCharacters(in: .whitespacesAndNewlines)
                            return name.isEmpty ? "\(usesTeams ? "Takım" : "Oyuncu") \(index + 1)" : name
                        }
                        if store.put(Match(kind: kind, players: players, lowWins: lowWins, batakVariant: kind == .batak ? batakVariant : nil)) { dismiss() }
                    }.font(.headline).frame(maxWidth: .infinity)
                }
            }.navigationTitle("\(kind.rawValue) · Yeni masa")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Vazgeç") { dismiss() } } }
                .onAppear { lowWins = kind.lowWins }
        }
    }
}

struct MatchView: View {
    let id: UUID
    @EnvironmentObject var store: MatchStore
    @State private var entry = false
    @State private var editing: UUID?
    @State private var confirmFinish = false
    @State private var confirmUndo = false
    @State private var confirmReopen = false
    private var match: Match? { store.matches.first { $0.id == id } }
    var body: some View {
        Group {
            if let match {
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        HStack {
                            Label(match.finished ? "Tamamlandı" : "Masa açık", systemImage: match.finished ? "checkmark.circle" : "circle.fill").foregroundStyle(.mint)
                            Spacer(); Text("\(match.rounds.count) el").foregroundStyle(.secondary)
                        }.font(.caption.bold())
                        Text(match.resultSummary)
                            .font(.title2.bold())
                        Text(match.lowWins ? "Düşük toplam puan kazanır" : "Yüksek toplam puan kazanır").font(.caption).foregroundStyle(.secondary)
                        ForEach(match.players.indices, id: \.self) { index in
                            HStack {
                                Text(match.players[index]).font(.headline)
                                Spacer()
                                Text("\(match.totals[index])").font(.system(size: 32, weight: .bold, design: .rounded)).monospacedDigit()
                            }.padding(20).background(panel, in: RoundedRectangle(cornerRadius: 20))
                        }
                        if !match.finished {
                            Button { editing = nil; entry = true } label: {
                                Label("El puanı ekle", systemImage: "plus").font(.headline).frame(maxWidth: .infinity).padding(12)
                            }.buttonStyle(.borderedProminent).foregroundStyle(canvas)
                        }
                        if !match.rounds.isEmpty {
                            Text("El defteri").font(.title3.bold())
                            ForEach(Array(match.rounds.enumerated()).reversed(), id: \.element.id) { index, round in
                                Button { editing = round.id; entry = true } label: {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack { Text("\(index + 1). el").bold(); Spacer(); if !match.finished { Image(systemName: "pencil") } }
                                        ForEach(match.players.indices, id: \.self) { p in
                                            HStack { Text(match.players[p]); Spacer(); Text("\(round.scores[p])").monospacedDigit() }
                                        }
                                        if !round.note.isEmpty { Text(round.note).foregroundStyle(.secondary) }
                                    }.font(.subheadline).padding(16).background(panel, in: RoundedRectangle(cornerRadius: 16))
                                }.buttonStyle(.plain).disabled(match.finished)
                            }
                        }
                        if match.finished {
                            Button("Maçı yeniden aç") { confirmReopen = true }.frame(maxWidth: .infinity).buttonStyle(.bordered)
                            Text("Puanları düzeltmek veya yeni el eklemek için maçı yeniden aç.").font(.caption).foregroundStyle(.secondary)
                        }
                        if !match.finished && !match.rounds.isEmpty {
                            Button("Son eli geri al", role: .destructive) { confirmUndo = true }
                            Button("Maçı bitir") { confirmFinish = true }.frame(maxWidth: .infinity).buttonStyle(.bordered)
                        }
                    }.padding(22)
                }.background(canvas).navigationTitle(match.title)
                    .sheet(isPresented: $entry) { ScoreEntryView(match: match, roundID: editing) }
                    .confirmationDialog("Maç tamamlansın mı?", isPresented: $confirmFinish, titleVisibility: .visible) {
                        Button("Maçı bitir") { var changed = match; if changed.finish() { store.put(changed) } }
                    }
                    .confirmationDialog("Maç yeniden açılsın mı?", isPresented: $confirmReopen, titleVisibility: .visible) {
                        Button("Maçı yeniden aç") { var changed = match; if changed.reopen() { store.put(changed) } }
                    }
                    .confirmationDialog("Son el silinsin mi?", isPresented: $confirmUndo, titleVisibility: .visible) {
                        Button("Son eli sil", role: .destructive) { var changed = match; if changed.undoLastRound() { store.put(changed) } }
                    }
            } else { ContentUnavailableView("Masa bulunamadı", systemImage: "table.furniture") }
        }
    }
}

struct ScoreEntryView: View {
    let match: Match
    let roundID: UUID?
    @EnvironmentObject var store: MatchStore
    @Environment(\.dismiss) private var dismiss
    @State private var values: [String] = []
    @State private var note = ""
    private var parsed: [Int]? {
        let numbers = values.compactMap { Int($0.trimmingCharacters(in: .whitespaces)) }
        return numbers.count == match.players.count && numbers.allSatisfy { (-100_000...100_000).contains($0) } ? numbers : nil
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    ForEach(match.players.indices, id: \.self) { index in
                        HStack {
                            Text(match.players[index]); Spacer()
                            if values.indices.contains(index) {
                                TextField("0", text: $values[index]).multilineTextAlignment(.trailing).keyboardType(.numbersAndPunctuation).frame(width: 120)
                            }
                        }
                    }
                } header: { Text("\(roundID == nil ? "Yeni el" : "Eli düzenle") · Sonuç puanları") } footer: {
                    Text("Her oyuncuya puan gir. Sıfır ve negatif değerler kullanılabilir. İzin verilen aralık: −100.000 ile 100.000.")
                }
                Section("El notu") { TextField("Örn. ceza, ihale, özel durum", text: $note) }
            }.navigationTitle("El puanları").toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Vazgeç") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Kaydet") {
                        guard let scores = parsed else { return }
                        guard var changed = store.matches.first(where: { $0.id == match.id }) else { return }
                        if let roundID {
                            guard changed.replaceRound(id: roundID, scores: scores, note: note) else { return }
                        } else { guard changed.add(scores: scores, note: note) else { return } }
                        if store.put(changed) { dismiss() }
                    }.disabled(parsed == nil)
                }
            }.onAppear {
                let existing = match.rounds.first { $0.id == roundID }
                values = existing?.scores.map(String.init) ?? Array(repeating: "", count: match.players.count)
                note = existing?.note ?? ""
            }
        }
    }
}

struct HistoryView: View {
    @EnvironmentObject var store: MatchStore
    @State private var deleting: UUID?
    var body: some View {
        NavigationStack {
            List {
                if store.matches.isEmpty { ContentUnavailableView("Henüz bir masa kurulmadı", systemImage: "clock", description: Text("Başladığın ve tamamladığın maçlar burada görünür.")) }
                ForEach(store.matches) { match in
                    NavigationLink { MatchView(id: match.id) } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack { Text(match.title).font(.headline); Spacer(); Text(match.finished ? "Bitti" : "Devam ediyor").font(.caption).foregroundStyle(.mint) }
                            Text(match.players.joined(separator: " · ")).font(.subheadline).lineLimit(2)
                            Text("\(match.created.formatted(date: .abbreviated, time: .shortened)) · \(match.rounds.count) el").font(.caption).foregroundStyle(.secondary)
                        }.padding(.vertical, 6)
                    }.swipeActions { Button("Sil", role: .destructive) { deleting = match.id } }
                }
            }.navigationTitle("El defteri")
                .confirmationDialog("Bu maç ve tüm elleri silinsin mi?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                    Button("Maçı sil", role: .destructive) { if let deleting { store.remove(deleting) }; deleting = nil }
                }
        }
    }
}

struct ToolsView: View {
    @State private var diceCount = 2
    @State private var dice: [Int] = []
    @State private var coin: String?
    @State private var flips = 0
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text("Şansını masaya getir.").font(.largeTitle.bold())
                    VStack(spacing: 22) {
                        HStack { Label("Zar", systemImage: "dice.fill").font(.title2.bold()); Spacer(); Picker("Zar sayısı", selection: $diceCount) { Text("1 zar").tag(1); Text("2 zar").tag(2); Text("3 zar").tag(3) }.pickerStyle(.menu).onChange(of: diceCount) { _, _ in dice = [] } }
                        HStack(spacing: 18) {
                            if dice.isEmpty { Image(systemName: "dice").foregroundStyle(.secondary).font(.system(size: 68)) }
                            ForEach(dice.indices, id: \.self) { index in
                                Image(systemName: "die.face.\(dice[index]).fill").font(.system(size: 68)).foregroundStyle(.mint).accessibilityLabel("\(index + 1). zar: \(dice[index])")
                            }
                        }.frame(height: 90).accessibilityElement(children: .combine)
                        Text(dice.isEmpty ? "Atış için hazır" : "Toplam: \(dice.reduce(0, +))").foregroundStyle(.secondary)
                        Button("Zar at") { dice = (0..<diceCount).map { _ in Int.random(in: 1...6) } }.buttonStyle(.borderedProminent).controlSize(.large)
                    }.padding(24).frame(maxWidth: .infinity).background(panel, in: RoundedRectangle(cornerRadius: 26))
                    VStack(spacing: 20) {
                        Label("Yazı · Tura", systemImage: "circle.lefthalf.filled").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
                        ZStack {
                            Circle().fill(.yellow.opacity(0.14)).frame(width: 130, height: 130)
                            Text(coin ?? "?").font(.system(size: 30, weight: .bold, design: .rounded)).foregroundStyle(.yellow)
                        }.accessibilityLabel(coin.map { "Sonuç: \($0)" } ?? "Henüz atılmadı")
                        Text(flips == 0 ? "İlk kim başlasın?" : "\(flips). atış").font(.caption).foregroundStyle(.secondary)
                        Button("Parayı at") { coin = Bool.random() ? "Yazı" : "Tura"; flips += 1 }.buttonStyle(.borderedProminent).controlSize(.large)
                    }.padding(24).frame(maxWidth: .infinity).background(panel, in: RoundedRectangle(cornerRadius: 26))
                }.padding(22)
            }.background(canvas).navigationTitle("Araçlar").navigationBarTitleDisplayMode(.inline)
        }
    }
}

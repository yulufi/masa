# Masa geliştirme planı

28 Ekim 2026 · Öncelik: iPhone · Ürün adı geçici

Güncel ekip kaynakları bu deponun `ios/` ve `web/` klasörleridir. Önceki teslim klasörleri arşiv kopyalarıdır. Üç insan ekip üyesi kendi dallarında çalışır; Mac sahibi cihaz derlemesini doğrular. Yapay zekâ ekibi bu iş bölümünü destekler.

## Başlangıç durumu

Kaynak incelemesine göre King, Okey, 101, Küt, Batak ve Pişti ortak bir elle puan girilen skor defteri kullanıyor. Toplam, yüksek/düşük puanla kazanma, beraberlik, el düzeltme, son eli geri alma, maçı bitirme ve yerel kayıt var. Batak için İhaleli, İhalesiz, Eşli, Gömmeli (3 kişi) ve 3-5-8 seçilebiliyor; tür ve puan hanesi sayısı saklanıyor. Eşli türde iki takımın toplamı tutuluyor, dört kişinin ayrı oyuncu profili yok. Zar (1–3 adet) ve yazı-tura mevcut.

Bu seçenekler henüz oyunlara özel otomatik puanlama anlamına gelmiyor. İhale, kontrat, kart hesabı, ceza ve 3-5-8 hesapları kullanıcı tarafından yapılıyor. Oyuncu rehberi ve oyuncuya bağlı istatistikler henüz yok.

İki ayrı uygulama var: SwiftUI ile iPhone kaynak projesi ve tarayıcı önizlemesi. iPhone maçları cihazdaki dosyada, önizleme maçları o tarayıcının yerel depolamasında tutuluyor; birbirine aktarılmıyor. Özellikler eş zamanlı tamamlanmış kabul edilmemeli. Aynı kabul örnekleriyle iki sürümün davranışları kontrol edilmeli.

Bu Mac'te tam Xcode yerine Command Line Tools bulunuyor. Kaynak ve bağımsız mantık testleri iPhone derlemesi veya cihaz denemesinin yerini tutmuyor. iOS arayüzü, imzalama ve gerçek cihazda çalışma henüz doğrulanmış değil.

Kullanıcının dosya olarak dışa aktarıp geri yükleyebileceği bir yedekleme akışı yok. Tarayıcı verileri temizlenirse veya iPhone uygulaması silinirse kayıtlar kaybolabilir. İlk teknik öncelik, bozuk kaydı korumak ve taşınabilir yedeklemeyi eklemek.

## Ekip ve çalışma düzeni

- **Ürün ve oyun kuralları:** En önemli kullanım sorununu seçer; kesinleşen kuralları örnek ellerle kaydeder.
- **iPhone geliştirme:** Asıl ürünü geliştirir; kayıt uyumluluğu ve cihaz deneyiminden sorumludur.
- **Arayüz ve önizleme:** Kullanıcının yerelde deneyebileceği akışları hazırlar; iPhone sürümüyle farkları görünür tutar.
- **Kalite kontrol:** Hataları tekrar üretir, veri kaybını ve hesap hatalarını denetler; kabul örneklerini doğrular.

Her çevrimde bir somut sorun seçilir, küçük bir değişiklik yapılır, ilgili testler çalıştırılır ve değişiklik ile kalan sınırlar kısa biçimde raporlanır. Çalışan alanlar sırf yenilemek için değiştirilmez. Yeni sunucu, yayın, hesap sistemi veya ücretli servis bu planın parçası değildir. Otomatik devam çalışmalarında kullanıcı kararı gereken kural hesapları bekletilir; aynı durum tekrar tekrar bildirilmez. Kullanıcının gerçek oyun deneyimi, sonraki önceliği belirler.

## Üç geliştirme aşaması

### 1. Güvenilir skor defteri

Önce kayıt doğrulama, kaydetme hataları, beraberlik anlatımı ve tamamlanmış maç düzeltme akışı ele alınır. Ardından sürüm bilgisi taşıyan dosya yedeği dışa/içe aktarma eklenir. İçe aktarmada önizleme ve çakışma kararı sunulur; geçerli mevcut kayıtlar sessizce silinmez.

**Kabul:** Eksik/geçersiz puan reddedilir; sıfır ve negatif puan doğru toplanır. El düzeltme ve geri alma toplamı günceller. Yeniden açılışta aynı maç korunur. Bozuk kayıt veya başarısız kaydetme mevcut veriyi değiştirmez. Yedekten geri yüklenen maçın türü, isimleri, elleri ve toplamları aynı kalır. Tarayıcı ve iPhone durumları ayrı raporlanır.

### 2. Batak kuralları ve hızlı masa kurma

Kullanıcının masa kuralları netleşince beş tür için ayrı girişler hazırlanır: gerekli yerde ihale/alınan el, eşli takım hesabı ve 3-5-8 hedefleri. Kurallar maç başlangıcında seçilir ve o maça kaydedilir; sonradan genel ayar değişmesi eski maçın sonucunu değiştirmez. Kayıtlı isimler ve tekrar aynı masayı kurma eklenir.

**Kabul:** Her türde doğru oyuncu/takım düzeni zorunludur. Her kesinleşmiş kural için başarılı el, batma, sınır değer ve beraberlik örneği bulunur. El verisi düzeltildiğinde puan yeniden doğru hesaplanır. Eski elle girilmiş maçlar aynı toplamla açılır. Kesinleşmemiş kurallarda otomatik sonuç üretilmez.

### 3. Diğer oyunlar ve iPhone denemesi

King, Okey, 101, Küt ve Pişti sırayla kendi puan girişlerine kavuşur. Her oyun kendi kabul örneklerini tamamlamadan sonraki otomatik hesaplamaya geçilmez. Oyuncu kimlikleri yerleştikten sonra oyun türüne göre istatistik eklenir. Xcode kurulduğunda iPhone'da tüm temel akışlar denenir.

**Kabul:** Her oyunda gerçek masa örneklerinin hesabı beklenen sonuçla eşleşir. İstatistik yalnızca tamamlanmış maçları sayar; yeniden açma veya silme doğru yansır. Küçük iPhone ekranında ve büyük yazı ayarında kritik düğmeler kullanılabilir; VoiceOver alanları anlaşılır okur. Uygulama kapanıp açılınca maç korunur. Zar sonuçları 1–6 aralığında, sayısı seçime uygun ve toplamı doğrudur; yazı-tura yalnızca iki geçerli sonuç verir. Fiziksel iPhone denemesi tamamlanmadan “iPhone'da doğrulandı” denmez.

## Otomatik puanlama öncesi gerekli kararlar

1. **Batak:** Her tür için tutan/tutmayan ihale, fazla el, sıfır el cezası ve maç bitişi nasıl hesaplanıyor? Eşlide kim ihale verir? Gömmelide hangi kurallar değişir? 3-5-8'de hedef dönüşümü, eksik/fazla eller ve sonraki ele taşınan sonuç nasıl uygulanır?
2. **King:** Oynanan kontratlar, adetleri/sırası ve her kontratın puan değerleri neler? Koz ellerinin hesabı ve maç bitişi nasıl?
3. **Okey, 101 ve Küt:** Her biri için kullanılan bitiş/ceza değerleri neler? 101'de açma/katlama; Küt'te tur koşulları ve sırası nasıl? Maç kaç elde veya hangi puanda biter?
4. **Pişti:** Kart değerleri, vale piştisi ve kart çoğunluğu beraberliği nasıl sayılıyor? Bireysel/eşli seçenekleri ve bitiş hedefi ne?

Bu kararlar oyunu engellemez: kullanıcı mevcut elle puan girme akışını kullanabilir. İlk netleştirilecek konu Batak'tır; diğer sorular ilgili oyun geliştirilirken sorulur.

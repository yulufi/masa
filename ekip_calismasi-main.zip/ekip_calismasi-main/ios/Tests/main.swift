import Foundation

func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
    if !condition() { fatalError(message) }
}
var match = Match(kind: .yuzbir, players: ["Ece", "Can"], lowWins: true)
expect(match.leaders.isEmpty, "No leader before a round")
expect(!match.add(scores: [1], note: ""), "Reject missing player score")
expect(!match.add(scores: [100001, 0], note: ""), "Reject out of bounds score")
expect(match.add(scores: [40, 20], note: "İlk el"), "Add round")
expect(match.add(scores: [-40, 10], note: "Ceza dahil"), "Accept negative score")
expect(match.totals == [0, 30], "Sum signed scores")
expect(match.leaders == ["Ece"], "Low total wins")
match.lowWins = false
expect(match.leaders == ["Can"], "High total wins")
match.rounds[0].scores = [70, 20]
expect(match.leaders == ["Ece", "Can"], "Shared lead")
match.rounds.removeLast()
expect(match.totals == [70, 20], "Undo updates totals")
match.finished = true
expect(!match.add(scores: [0, 0], note: ""), "Finished match rejects new rounds")
let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
defer { try? FileManager.default.removeItem(at: folder) }
let archive = MatchArchive(url: folder.appendingPathComponent("matches.json"))
let empty = try archive.load()
expect(empty.isEmpty, "Missing archive starts empty")
try archive.save([match])
let restored = try archive.load()
expect(restored.count == 1 && restored[0].id == match.id, "Preserve match identity")
expect(restored[0].totals == match.totals && restored[0].rounds[0].note == "İlk el", "Preserve scores and Turkish note")
try Data("invalid".utf8).write(to: archive.url)
do { _ = try archive.load(); fatalError("Corruption must not silently erase data") } catch { }
print("PASS: score validation, signed totals, winner direction, ties, editing, undo, completion, persistence, corrupted data")

for variant in BatakVariant.allCases {
    let players = (1...variant.scoreCount).map { "\(variant.isTeam ? "Takım" : "Oyuncu") \($0)" }
    var batak = Match(kind: .batak, players: players, lowWins: false, batakVariant: variant)
    expect(batak.validArrangement, "Correct arrangement for \(variant.rawValue)")
    expect(batak.add(scores: Array(repeating: 10, count: variant.scoreCount), note: "El"), "Accept variant scores")
    let data = try JSONEncoder().encode(batak)
    let decoded = try JSONDecoder().decode(Match.self, from: data)
    expect(decoded.batakVariant == variant && decoded.title.contains(variant.rawValue), "Preserve variant and title")
    batak.players.append("Fazla oyuncu")
    expect(!batak.add(scores: Array(repeating: 0, count: batak.players.count), note: ""), "Reject incompatible player count")
}
expect(BatakVariant.esli.scoreCount == 2 && BatakVariant.esli.playerCount == 4, "Two teams, four people")
expect(BatakVariant.gommeli.scoreCount == 3 && BatakVariant.ucBesSekiz.scoreCount == 3, "Three-person modes")
var legacy = try JSONSerialization.jsonObject(with: JSONEncoder().encode(match)) as! [String: Any]
legacy.removeValue(forKey: "batakVariant")
let migrated = try JSONDecoder().decode(Match.self, from: JSONSerialization.data(withJSONObject: legacy))
expect(migrated.batakVariant == nil && migrated.totals == match.totals, "Read older saves without variant")
print("PASS: all five Batak variants, team/player counts, variant persistence, incompatible arrangement rejection, legacy save compatibility")

var lifecycle = Match(kind: .batak, players: ["A", "B", "C"], lowWins: false, batakVariant: .ucBesSekiz)
expect(!lifecycle.finish() && !lifecycle.finished, "Empty match cannot finish")
expect(!lifecycle.undoLastRound(), "Empty undo is safe")
expect(lifecycle.leaders.isEmpty && lifecycle.resultSummary == "İlk el sizden.", "Empty match has no winner")
expect(lifecycle.add(scores: [5, 5, 3], note: ""), "Add tied round")
let roundID = lifecycle.rounds[0].id
expect(lifecycle.resultSummary == "Eşit puan: A & B", "Open match shows shared lead")
expect(lifecycle.finish(), "Finish valid played match")
expect(lifecycle.resultSummary == "Beraberlik: A & B", "Finished tie is explicit")
expect(!lifecycle.replaceRound(id: roundID, scores: [1, 2, 3], note: ""), "Closed round cannot change")
expect(!lifecycle.undoLastRound(), "Closed round cannot be removed")
try archive.save([lifecycle])
var reopened = try archive.load()[0]
expect(reopened.reopen() && !reopened.finished, "Reopen persisted completed game")
expect(reopened.rounds[0].id == roundID && reopened.totals == [5, 5, 3], "Reopen preserves scores")
expect(!reopened.replaceRound(id: UUID(), scores: [1, 2, 3], note: ""), "Missing edit never appends a round")
expect(!reopened.replaceRound(id: roundID, scores: [1], note: ""), "Edit validates all scores")
expect(reopened.replaceRound(id: roundID, scores: [1, 2, 3], note: "Düzeltildi"), "Reopened match accepts correction")
expect(reopened.undoLastRound() && reopened.rounds.isEmpty && reopened.leaders.isEmpty, "Undo final round clears leaders")
var malformed = lifecycle
malformed.rounds[0].scores = [7]
let preservedData = try Data(contentsOf: archive.url)
do { try archive.save([malformed]); fatalError("Must reject invalid save") } catch { }
let afterRejectedSave = try Data(contentsOf: archive.url)
expect(afterRejectedSave == preservedData, "Rejected save preserves archive")
try JSONEncoder().encode([malformed]).write(to: archive.url)
do { _ = try archive.load(); fatalError("Structurally invalid archive must fail") } catch { }
var noPlayers = Match(kind: .king, players: [], lowWins: false)
expect(!noPlayers.add(scores: [], note: ""), "Reject zero-player game")
print("PASS: reopen, completion guard, explicit ties, safe edits and undo, invalid archive protection")

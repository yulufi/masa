import test from 'node:test';
import assert from 'node:assert/strict';
import {games,variants,totals,leaders,resultSummary,validScores,validMatch,validMatches,readMatches,writeMatches,storageKey,roll} from './model.mjs';
const match=(extra={})=>({id:'test-1',game:'King',variant:null,players:['Ada','Ece'],low:false,rounds:[{scores:[10,-5],note:''}],finished:false,created:1700000000000,...extra});
const memory=raw=>({raw,writes:0,getItem(key){assert.equal(key,storageKey);return this.raw;},setItem(key,value){assert.equal(key,storageKey);this.raw=value;this.writes++;}});
test('all existing game and Batak variant records remain compatible',()=>{
  for(const [game] of games){if(game==='Batak')continue;assert.equal(validMatch(match({game})),true);}
  for(const [variant,count] of Object.entries(variants))assert.equal(validMatch(match({game:'Batak',variant,players:Array.from({length:count},(_,i)=>`Oyuncu ${i+1}`),rounds:[]})),true);
});
test('score totals and tied leaders handle negative scores and low scoring games',()=>{
  const m=match({rounds:[{scores:[10,-5],note:''},{scores:[-15,0],note:''}]});
  assert.deepEqual(totals(m),[-5,-5]);assert.deepEqual(leaders(m),['Ada','Ece']);
  assert.deepEqual(leaders(match({low:true})),['Ece']);assert.deepEqual(leaders(match({rounds:[]})),[]);
});
test('invalid nested records cannot reach totals or rendering',()=>{
  const bad=[null,{},match({players:null}),match({players:['Ada']}),match({players:['', 'Ece']}),match({rounds:[{}]}),match({rounds:[{scores:[1],note:''}]}),match({rounds:[{scores:[1,2],note:null}]}),match({low:'false'}),match({finished:1}),match({created:NaN}),match({game:'Unknown'}),match({game:'Batak',variant:'Eşli',players:['A','B','C']})];
  for(const m of bad)assert.equal(validMatch(m),false);
  assert.equal(validMatches([match(),match()]),false);
  for(const value of [null,{},[1,NaN],[1,Infinity],[1,2.5],[1,100001]])assert.equal(validScores(value,2),false);
  assert.equal(validScores([0,-100000],2),true);
});
test('invalid JSON and incompatible records preserve original bytes and refuse writes',()=>{
  for(const raw of ['', '{broken', 'null','{}','[{}]',JSON.stringify([match(),{}])]){
    const storage=memory(raw),state=readMatches(storage);
    assert.equal(state.locked,true);assert.equal(state.raw,raw);assert.deepEqual(state.matches,[]);
    assert.equal(writeMatches(storage,[],state).ok,false);assert.equal(storage.raw,raw);assert.equal(storage.writes,0);
  }
});
test('empty and valid storage can save and restore matches',()=>{
  for(const raw of [null,'[]',JSON.stringify([match()])]){
    const storage=memory(raw),state=readMatches(storage);
    assert.equal(state.locked,false);
    const result=writeMatches(storage,[match()],state);assert.equal(result.ok,true);
    assert.equal(result.raw,storage.raw);assert.deepEqual(readMatches(storage).matches,[match()]);
  }
});
test('concurrent tab writes are rejected without overwriting unseen matches',()=>{
  const storage=memory('[]'),state=readMatches(storage);
  storage.raw=JSON.stringify([match({id:'another-tab'})]);const original=storage.raw;
  assert.equal(writeMatches(storage,[match()],state).reason,'conflict');assert.equal(storage.raw,original);assert.equal(storage.writes,0);
});
test('access and quota failures leave existing storage untouched',()=>{
  const inaccessible={getItem(){throw Error('denied');}};
  assert.equal(readMatches(inaccessible).locked,true);
  const storage=memory('[]'),state=readMatches(storage);storage.setItem=()=>{throw Error('quota');};
  assert.equal(writeMatches(storage,[match()],state).reason,'access');assert.equal(storage.raw,'[]');
  assert.equal(writeMatches(storage,[{}],state).reason,'format');
});
test('finished matches can reopen without changing scores, players or creation time',()=>{
  const finished=match({finished:true}),storage=memory(JSON.stringify([finished])),state=readMatches(storage);
  assert.equal(writeMatches(storage,[{...finished,finished:false}],state).ok,true);
  assert.deepEqual(readMatches(storage).matches,[match()]);
});
test('dice stay in bounds for supported counts',()=>{
  for(const count of [1,2,3]){const values=roll(count);assert.equal(values.length,count);assert.ok(values.every(n=>Number.isInteger(n)&&n>=1&&n<=6));}
});

test('result summary distinguishes ties, winners and games without rounds',()=>{
  assert.equal(resultSummary(match({rounds:[]})),'İlk el sizden.');
  assert.equal(resultSummary(match()),'Ada önde');
  assert.equal(resultSummary(match({finished:true})),'Ada kazandı');
  assert.equal(resultSummary(match({low:true,finished:true})),'Ece kazandı');
  const rounds=[{scores:[5,5],note:''}];
  assert.equal(resultSummary(match({rounds})),'Eşit puan · Ada & Ece');
  assert.equal(resultSummary(match({rounds,finished:true})),'Beraberlik · Ada & Ece');
});
test('finished matches require at least one round and invalid saved versions stay protected',()=>{
  const invalid=match({finished:true,rounds:[]});
  assert.equal(validMatch(invalid),false);
  assert.equal(validMatch(match({rounds:[]})),true);
  const raw=JSON.stringify([invalid]),storage=memory(raw),state=readMatches(storage);
  assert.equal(state.locked,true);assert.equal(writeMatches(storage,[],state).ok,false);
  assert.equal(storage.raw,raw);assert.equal(storage.writes,0);
});

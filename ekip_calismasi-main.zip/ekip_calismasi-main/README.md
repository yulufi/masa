# Masa — ekip çalışması

[![Masa kontrolleri](https://github.com/caganegealpaydin-collab/ekip_calismasi/actions/workflows/checks.yml/badge.svg)](https://github.com/caganegealpaydin-collab/ekip_calismasi/actions/workflows/checks.yml)

King, Okey, 101, Küt, Batak ve Pişti için Türkçe skor defteri; zar ve yazı-tura araçları. Hedef ürün iPhone uygulamasıdır. Web sürümü ayrı, hızlı denenebilir bir önizlemedir. Oyunlara özel otomatik ihale, kontrat ve ceza hesapları henüz tamamlanmadı; sonuç puanları elle girilir.

Ortak GitHub deposu: [caganegealpaydin-collab/ekip_calismasi](https://github.com/caganegealpaydin-collab/ekip_calismasi). Üç kişilik ekibin ortak kaynak kodu bu depodadır.

## Klasörler

| Klasör | İçerik |
| --- | --- |
| `ios/` | SwiftUI iPhone uygulaması, Xcode projesi ve mantık testleri |
| `web/` | Mac, Windows veya Linux tarayıcısında denenebilir önizleme |
| `docs/` | Ekip rehberi, ürün planı, kural kararları, değişiklik günlüğü |
| `.github/` | İnceleme/görev şablonları ve otomatik kontroller |

## Web önizlemesini açma — herkes

Node.js 22 veya üzeri ve Python 3 kurulu olmalıdır. Terminali bu README'nin bulunduğu klasörde aç:

```sh
python3 -m http.server 5173 --bind 127.0.0.1 --directory web
```

Windows'ta `python3` bulunmuyorsa aynı komutta `py -3` kullan. Tarayıcıda http://127.0.0.1:5173 adresini aç. Sunucuyu kapatmak için terminalde Ctrl+C kullan. 5173 başka bir uygulama tarafından kullanılıyorsa 5174 gibi boş bir port seç.

Bu adres her kişinin kendi bilgisayarını gösterir. Ortak bir internet adresi değildir. Kayıtlar tarayıcıya ve adrese özeldir; ekip üyeleri veya iOS sürümü arasında eşitlenmez.

Web testleri:

```sh
node --check web/app.mjs
node --test web/model.test.mjs
```

## iPhone sürümü — Mac

1. Tam Xcode kurulumu gerekir. `ios/Masa.xcodeproj` dosyasını aç.
2. Masa şemasını ve bir iPhone simülatörünü seç; Run kullan.
3. Fiziksel iPhone için kendi Apple hesabını Xcode'a ekle; Signing & Capabilities altında Team seç ve `com.example.masa` kimliğini kendine ait benzersiz kimlikle değiştir.

Bağımsız mantık testleri (Mac terminali, proje kökünde):

```sh
swiftc ios/Masa/Game.swift ios/Tests/main.swift -o /tmp/masa-tests
/tmp/masa-tests
```

Foundation mantık testleri ve GitHub Actions üzerinde imzasız iPhone simülatör derlemesi geçti. Güncel sonuçlar yukarıdaki kontrol bağlantısında bulunur. Bu Mac'te tam Xcode henüz yoktur; fiziksel cihaz kurulumu, imzalama ve gerçek iPhone deneyimi ayrıca doğrulanmalıdır.

## Birlikte geliştirme

Üç kişi de yerelde commit oluşturabilir. GitHub'a dal göndermek için depo sahibinin yazma erişimi vermesi ve davetin kabul edilmesi gerekir. Her görev ayrı dalda geliştirilir, inceleme isteğiyle (pull request) ana sürüme eklenir. Ayrıntılar [ekip rehberinde](docs/EKIP_REHBERI.md).

Otomatik kontroller, bu klasörlerin tamamı deponun köküne yüklendikten ve GitHub Actions etkin olduktan sonra çalışır. Testlerin geçmesi henüz burada denenmemiş iPhone ekranlarının doğru olduğunu garanti etmez. `main` dalının kurallarla korunması ayrıca GitHub ayarlarından yapılmalıdır; bu paket onu etkinleştirmez.

- [Geliştirme planı](docs/GELISTIRME_PLANI.md)
- [Oyun kural kararları](docs/OYUN_KURALLARI.md)
- [Değişiklik günlüğü](docs/DEGISIKLIKLER.md)

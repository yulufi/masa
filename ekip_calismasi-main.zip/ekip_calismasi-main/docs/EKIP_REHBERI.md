# Üç kişilik ekip çalışma rehberi

## Erişim

Depo sahibi iki ekip üyesini GitHub Settings → Collaborators bölümünden davet eder. Organizasyon deposuysa uygun ekip/depo rolü üzerinden Write erişimi verilir. Davetler kabul edilmeden yazma erişimi oluşmaz. Herkes kendi hesabını kullanır.

Commit kendi bilgisayarında oluşturulur. Push o commitleri GitHub'a gönderir. Pull request değişiklikleri incelemeye sunar. Merge onaylanan değişiklikleri ana sürüme ekler.

## İlk kurulum

Git ve tercihen GitHub Desktop kur. Bu depoyu kendi bilgisayarına klonla:

```sh
git clone https://github.com/caganegealpaydin-collab/ekip_calismasi.git
cd ekip_calismasi
```

GitHub Desktop kullananlar File → Clone repository ile aynı depoyu seçebilir. Web önizlemesi için kök README'deki adımları izle. Windows/Linux kullananlar kod ve test geliştirebilir; iPhone derlemesi Mac/Xcode gerektirir.

## Her görev için

1. GitHub'da bir görev aç: amaç, beklenen davranış ve kabul örneği yaz.
2. İşe başlamadan ana sürümü güncelle ve görev için yeni dal aç.
3. Küçük ve anlaşılır değişiklikler yap; ilgili testleri çalıştır.
4. Commit oluşturup kendi dalını gönder.
5. Hedefi `main` olan pull request aç; ekipten bir kişi incelesin.
6. Test ve inceleme tamamlanınca birleştir. Diğer üyeler güncel ana sürümü alsın.

Örnek terminal akışı (proje kökünde):

```sh
git switch main
git pull --ff-only
git switch -c ozellik/oyuncu-rehberi
# Düzenleme ve testlerden sonra:
git add web/app.mjs web/model.mjs web/model.test.mjs
git commit -m "Oyuncu rehberini ekle"
git push -u origin ozellik/oyuncu-rehberi
```

Yalnız değiştirdiğin dosyaları ekle; örnekteki dosya listesi göreve göre değişir. GitHub Desktop'ta aynı akış: Fetch/Pull → New Branch → Changes → Commit → Publish/Push → Create Pull Request.

## İş bölümü

| Sorumlu | Ana alan |
| --- | --- |
| Mac sahibi | iPhone ekranları, cihaz testi ve sürüm hazırlama |
| Ekip üyesi 2 | Web deneyimi, tasarım ve oyuncu akışları |
| Ekip üyesi 3 | Oyun kural örnekleri, testler ve ürün görevleri |

Bu roller düzenleme yetkisini kısıtlamaz. Swift kodunu herkes değiştirebilir; birleştirmeden önce Mac üzerinde kontrol edilmelidir. Aynı dosyada aynı anda büyük değişiklik gerekiyorsa görevleri sırala; dal kullanmak çakışmayı otomatik çözmez.

## Ana sürüm ve inceleme

- Ekip anlaşması: `main` üzerinde doğrudan geliştirme yerine görev dalları kullanılır.
- GitHub'da mümkünse `main` için en az bir inceleme ve başarılı kontroller isteyen bir kural oluşturulur. Özel depolarda kullanılabilirlik hesap/plan ayarına bağlıdır; kural burada etkinleştirilmiş değildir.
- İlk aktarım mevcut uzak dosyalar incelenerek yapılır; force push kullanılmaz.
- Paylaşılan klasörde aynı dosyayı düzenlemek veya ZIP'leri ileri geri göndermek yerine Git geçmişi esas alınır.
- Oyun kuralı değişince örnek el ve beklenen sonuç önce docs/OYUN_KURALLARI.md dosyasına yazılır; test o örneği doğrular.
- Kayıt biçimi değişiyorsa eski kayıtların uyumluluğu ve kullanıcı verisinin korunması kontrol edilir.

## Yapay zekâ yardımcıları

Her kişi kendi bilgisayarında bir yardımcı kullanabilir. Yardımcıya görev numarasını ve kendi çalışma dalını ver; başka kişinin dalındaki devam eden işi ezmemesini iste. Bu sohbetteki günlük geliştirme takibi şu an yalnız bu Mac'in yerel kaynaklarına bağlıdır; ekip üyelerinin bilgisayarlarını veya GitHub'ı kendiliğinden eşitlemez. GitHub'a aktarım sonrasında yerel otomasyonun da güncel ortak depo üzerinden çalışması ayrıca düzenlenmelidir.

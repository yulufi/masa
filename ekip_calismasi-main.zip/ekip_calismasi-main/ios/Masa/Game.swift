import Foundation

enum GameKind: String, Codable, CaseIterable, Identifiable {
    case king = "King", okey = "Okey", yuzbir = "101", kut = "Küt", batak = "Batak", pisti = "Pişti"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .king: return "crown.fill"
        case .okey: return "square.grid.2x2.fill"
        case .yuzbir: return "number.square.fill"
        case .kut: return "suit.diamond.fill"
        case .batak: return "suit.spade.fill"
        case .pisti: return "suit.club.fill"
        }
    }
    var lowWins: Bool { self == .okey || self == .yuzbir || self == .kut }
}

enum BatakVariant: String, Codable, CaseIterable, Identifiable {
    case ihaleli = "İhaleli"
    case ihalesiz = "İhalesiz"
    case esli = "Eşli"
    case gommeli = "Gömmeli (3 kişi)"
    case ucBesSekiz = "3-5-8"
    var id: String { rawValue }
    var isTeam: Bool { self == .esli }
    var playerCount: Int { self == .gommeli || self == .ucBesSekiz ? 3 : 4 }
    var scoreCount: Int { isTeam ? 2 : playerCount }
    var arrangement: String { isTeam ? "4 oyuncu · 2 takım" : "\(playerCount) oyuncu · bireysel" }
}

struct ScoreRound: Codable, Identifiable {
    var id = UUID()
    var scores: [Int]
    var note: String
}

struct Match: Codable, Identifiable {
    var id = UUID()
    var kind: GameKind
    var players: [String]
    var lowWins: Bool
    var batakVariant: BatakVariant? = nil
    var title: String {
        guard kind == .batak, let batakVariant else { return kind.rawValue }
        return "Batak · \(batakVariant.rawValue)"
    }
    var validArrangement: Bool {
        guard (2...6).contains(players.count) else { return false }
        guard let batakVariant else { return true }
        return kind == .batak && players.count == batakVariant.scoreCount
    }
    var created = Date()
    var finished = false
    var rounds: [ScoreRound] = []
    var totals: [Int] {
        players.indices.map { index in rounds.reduce(0) { $0 + ($1.scores.indices.contains(index) ? $1.scores[index] : 0) } }
    }
    var leaders: [String] {
        guard !rounds.isEmpty, let best = lowWins ? totals.min() : totals.max() else { return [] }
        return players.indices.filter { totals[$0] == best }.map { players[$0] }
    }
    var validRecord: Bool {
        validArrangement && rounds.allSatisfy { validScores($0.scores) }
            && Set(rounds.map(\.id)).count == rounds.count
            && (!finished || !rounds.isEmpty)
    }
    private func validScores(_ scores: [Int]) -> Bool {
        scores.count == players.count && scores.allSatisfy { (-100_000...100_000).contains($0) }
    }
    var resultSummary: String {
        guard !rounds.isEmpty else { return "İlk el sizden." }
        let names = leaders.joined(separator: " & ")
        if leaders.count > 1 { return finished ? "Beraberlik: \(names)" : "Eşit puan: \(names)" }
        return "\(names) \(finished ? "kazandı" : "önde")"
    }
    @discardableResult mutating func finish() -> Bool {
        guard !finished, !rounds.isEmpty, validRecord else { return false }
        finished = true
        return true
    }
    @discardableResult mutating func reopen() -> Bool {
        guard finished else { return false }
        finished = false
        return true
    }
    @discardableResult mutating func replaceRound(id: UUID, scores: [Int], note: String) -> Bool {
        guard !finished, validArrangement, validScores(scores), let index = rounds.firstIndex(where: { $0.id == id }) else { return false }
        rounds[index].scores = scores
        rounds[index].note = note
        return true
    }
    @discardableResult mutating func undoLastRound() -> Bool {
        guard !finished, !rounds.isEmpty else { return false }
        rounds.removeLast()
        return true
    }
    mutating func add(scores: [Int], note: String) -> Bool {
        guard !finished, validArrangement, validScores(scores) else { return false }
        rounds.append(ScoreRound(scores: scores, note: note))
        return true
    }
}

struct MatchArchive {
    let url: URL
    func load() throws -> [Match] {
        guard FileManager.default.fileExists(atPath: url.path) else { return [] }
        let matches = try JSONDecoder().decode([Match].self, from: Data(contentsOf: url))
        try validate(matches)
        return matches
    }
    private func validate(_ matches: [Match]) throws {
        guard matches.allSatisfy(\.validRecord), Set(matches.map(\.id)).count == matches.count else {
            throw CocoaError(.fileReadCorruptFile)
        }
    }
    func save(_ matches: [Match]) throws {
        try validate(matches)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(matches).write(to: url, options: .atomic)
    }
}

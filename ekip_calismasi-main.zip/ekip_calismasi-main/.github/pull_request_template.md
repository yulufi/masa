## Değişiklik

Hangi sorunu çözüyor? Kullanıcı neyi farklı görecek?

## Kontrol

- [ ] İlgili testler çalıştırıldı; sonuç aşağıda.
- [ ] Kullanıcı kayıtları ve eski sürüm uyumluluğu değerlendirildi.
- [ ] Oyun kuralı değiştiyse örnek ve beklenen puan belgelendi.
- [ ] iOS değişikliği varsa Xcode sonucu veya doğrulama sınırı belirtildi.

Test sonucu:

İlgili görev:

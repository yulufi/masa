# Masa — değişiklik günlüğü

## 28 Ekim 2026 · İlk ekip incelemesi

**Ekip:** iOS geliştiricisi, web ve test geliştiricisi, ürün/oyun kuralları analisti; birleştirme ve son kontrol ana sohbette.

### Tamamlananlar

- iOS ve webde tamamlanan maçı onayla yeniden açma.
- Beraberlik ve el girilmemiş masa için açık sonuç metinleri.
- iOS'ta maç bitirme, yeniden açma, el düzeltme ve geri almanın model düzeyinde kontrolü; güncel kayıt üzerinden düzenleme.
- iOS arşivinde puan dizisi/oyuncu sayısı, yinelenen kimlik ve maç durumunun doğrulanması; hatalı verinin üzerine yazılmaması.
- Webde kayıt biçimi doğrulaması ve sorunlu kaynak verisini koruyan yazma engeli; sorunlu ham kaydı indirme olanağı.
- Webde başka sekmenin değiştirdiği kayda eski verinin yazılmasını fark edip durdurma. Bu, eşzamanlı iki yazma için işlemsel kilit değildir.
- Üç aşamalı ürün planı ve her aşama için kabul ölçütleri.
- Her gün 10.00 için bu sohbete bağlı geliştirme takibi oluşturuldu.

### Doğrulama

- iOS Foundation test programının üç test grubu geçti; kayıt koruma ve yaşam döngüsü kontrolleri dahil.
- Swift kaynak sözdizimi kontrolü geçti.
- Webde 11 kalıcı Node testi ve uygulama sözdizimi kontrolü geçti.
- Yerel önizleme tarayıcıda açıldı; mevcut kullanıcı maçı korunarak zar ve yazı-tura akışı denendi.
- Gerçek iPhone derlemesi ve cihaz/görsel doğrulaması yapılmadı; bu Mac'te Xcode yok.

### Sıradaki işler

1. Sürüm bilgili dışa/içe aktarma ve kullanıcı verilerini koruyan geri yükleme.
2. Oyuncu rehberi ve aynı masayı yeniden kurma.
3. Kullanıcının masa kuralları netleştiğinde beş Batak türü için otomatik hesaplar.

Oyunlara özel ihale/ceza/kontrat hesapları henüz yapılmıyor. Web ve iOS verileri birbirine aktarılmıyor. Yerel önizleme internet yayını değildir.

## 28 Ekim 2026 · Üç kişilik ortak geliştirmeye hazırlık

- Güncel kaynaklar tek proje altında ios/, web/ ve docs/ olarak toplandı.
- Üç kişilik dal, inceleme ve birleştirme rehberi eklendi.
- Görev ve pull request şablonları hazırlandı.
- GitHub Actions için web mantık testleri ile Mac üzerinde Swift mantık testi ve simülatör derlemesi tanımlandı. Uzak iş akışı henüz GitHub'da çalıştırılmadı.
- Yeni klasör düzeninde 11 web testi ve üç Swift test grubu geçti.
- Otomasyonun kaynak yolları yeni ekip projesine geçirildi; uzak depoya yazma bu aşamada yapılmaz.
- Henüz GitHub'a dosya aktarımı, ekip daveti veya main koruma ayarı yapılmadı.

## 28 Ekim 2026 · GitHub başlangıç aktarımı

Proje, mevcut ilk commit korunarak caganegealpaydin-collab/ekip_calismasi deposuna aktarılmak üzere hazırlandı. Kök README ve katkı rehberi ortak depo düzenine uyarlandı; platformlar arasında tutarlı satır sonları eklendi. İlk aktarımın kontrol sonuçları GitHub Actions üzerinde izlenir. Bu kayıt tek başına uzak kontrollerin başarılı olduğu anlamına gelmez.

İlk GitHub kontrolünde web testleri ile Mac üzerinde Swift mantık testleri ve imzasız iPhone simülatör derlemesi başarılı oldu. Fiziksel cihaz testi henüz yapılmadı.

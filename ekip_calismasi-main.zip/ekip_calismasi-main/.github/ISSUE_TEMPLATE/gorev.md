---
name: Geliştirme görevi
about: Bir özellik, hata veya oyun kuralı kararı
---
## Amaç / sorun

## Beklenen davranış

## Kabul örneği

Girdiler:
Beklenen sonuç:

## Alan

Web / iOS / oyun kuralları / tasarım

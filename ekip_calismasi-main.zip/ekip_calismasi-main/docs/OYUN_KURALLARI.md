# Oyun kural kararları

Durum: Otomatik puanlama için masa kuralları henüz kesinleşmedi. Mevcut uygulama elin sonuç puanını elle alır.

## Kesin kapsam

King, Okey, 101, Küt, Pişti. Batak türleri: İhaleli, İhalesiz, Eşli, Gömmeli (3 kişi), 3-5-8. Ek araçlar: 1–3 altı yüzlü zar ve yazı-tura.

## İlk karar: Batak

Her tür için aşağıdaki formu doldurun; genel bir internet kuralını otomatik olarak masanızın kuralı kabul etmeyin.

| Alan | Karar |
| --- | --- |
| Batak türü | Bekliyor |
| İhale/taahhüt nasıl belirlenir? | Bekliyor |
| Tutan el nasıl puanlanır? | Bekliyor |
| Tutmayan el nasıl puanlanır? | Bekliyor |
| Fazla/sıfır el hesabı | Bekliyor |
| Maç bitiş koşulu | Bekliyor |
| Eşli takım veya 3-5-8 hedef dönüşümü | Bekliyor |

En az üç örnek ekleyin: başarılı el, batma/eksik hedef, sınır/beraberlik. Her örnekte oyuncu girdileri, beklenen puanlar ve varsa sonraki ele taşınan değerleri yazın. Onaylı kurallar maç kaydına sürümüyle bağlanmadan eski sonuçları değiştirmeyin.
